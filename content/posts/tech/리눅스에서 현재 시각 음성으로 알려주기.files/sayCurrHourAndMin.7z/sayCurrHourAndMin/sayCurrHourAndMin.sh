#!/bin/bash
# mp3파일의 경로는 절대경로로 넣어야 cron에서 문제 없이 재생가능
baseDir="/home/bluedskim/utils/shell/sayCurrHourAndMin"

# 현재 시각 가져오기
currHour=$(date +"%I")
echo $currHour
# 현재 분 가져오기
currMin=$(date +"%M")
echo $currMin

vol=80
# 볼륨을 파일에서 읽어오려 할 때
#vol=`cat /home/odroid/Util/shell/sayCurrHourAndMin/volume.txt`
echo "volume : $vol"

# 시간 mp3 파일 
currHourMp3=$baseDir"/"$currHour"h.mp3"
# 분 mp3 파일
currMinMp3=$baseDir"/"$currMin"m.mp3"

# 해당 파일을 재생
#ffplay -nodisp -autoexit $currHourMp3 
#ffplay -nodisp -autoexit $currMinMp3
mplayer -volume $vol $currHourMp3 $currMinMp3
# 1초 쉬었다가
sleep 1
# 한번 더 파일을 재생
#ffplay -nodisp -autoexit $currHourMp3 
#ffplay -nodisp -autoexit $currMinMp3
mplayer -volume $vol $currHourMp3 $currMinMp3

